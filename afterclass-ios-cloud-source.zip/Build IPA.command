#!/bin/bash
set -euo pipefail

afterclass_root="$(cd "$(dirname "$0")" && pwd)"
cd "$afterclass_root"

afterclass_finish() {
    if [ -t 0 ]; then
        printf '\nPress Return to close this window.\n'
        read -r _ || true
    fi
}
trap afterclass_finish EXIT

if [ -d /Applications/Xcode.app/Contents/Developer ]; then
    export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
fi
if ! /usr/bin/xcrun --find xcodebuild >/dev/null 2>&1; then
    printf 'Install Xcode from the Mac App Store and open it once to finish setup.\n'
    exit 1
fi
if ! /usr/bin/xcrun --sdk iphoneos --show-sdk-path >/dev/null 2>&1; then
    printf 'Open Xcode and install its iOS platform support, then try again.\n'
    exit 1
fi

printf 'Building the iPhone app. This can take a few minutes…\n'
/usr/bin/xcrun xcodebuild \
    -project Afterclass.xcodeproj \
    -scheme Afterclass \
    -configuration Release \
    -sdk iphoneos \
    -destination 'generic/platform=iOS' \
    -derivedDataPath "$afterclass_root/build/DerivedData" \
    CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO \
    build

afterclass_app="$afterclass_root/build/DerivedData/Build/Products/Release-iphoneos/Afterclass.app"
afterclass_executable="$(/usr/libexec/PlistBuddy -c 'Print CFBundleExecutable' "$afterclass_app/Info.plist")"
if ! /usr/bin/file "$afterclass_app/$afterclass_executable" | /usr/bin/grep -q 'Mach-O.*arm64'; then
    printf 'The expected iPhone executable was not built. No IPA created.\n'
    exit 1
fi
afterclass_platform="$(/usr/libexec/PlistBuddy -c 'Print CFBundleSupportedPlatforms:0' "$afterclass_app/Info.plist")"
if [ "$afterclass_platform" != iPhoneOS ]; then
    printf 'This is not an iPhone device build. No IPA created.\n'
    exit 1
fi

afterclass_package="$(/usr/bin/mktemp -d "$afterclass_root/build/package.XXXXXX")"
/bin/mkdir "$afterclass_package/Payload"
/usr/bin/ditto "$afterclass_app" "$afterclass_package/Payload/Afterclass.app"
/bin/mkdir -p "$afterclass_root/dist"
/bin/rm -f "$afterclass_root/dist/Afterclass-unsigned.ipa"
/usr/bin/ditto -c -k --keepParent "$afterclass_package/Payload" "$afterclass_root/dist/Afterclass-unsigned.ipa"
/bin/rm -rf "$afterclass_package"
printf '\nCreated: %s/dist/Afterclass-unsigned.ipa\nUse your installer to sign and install this IPA.\n' "$afterclass_root"
if [ "${CI:-}" != true ]; then
    /usr/bin/open "$afterclass_root/dist"
fi
