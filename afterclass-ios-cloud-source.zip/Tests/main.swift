import Foundation

let links: [(String, String?)] = [
    ("https://cuhsd.instructure.com/courses/42/assignments/7", "canvas-courses://cuhsd.instructure.com/courses/42/assignments/7"),
    ("https://cuhsd.instructure.com/courses/42/calendar_events/9", "canvas-courses://cuhsd.instructure.com/courses/42/calendar_events/9"),
    ("https://cuhsd.instructure.com/courses/42/grades", "canvas-courses://cuhsd.instructure.com/courses/42/grades"),
    ("https://cuhsd.instructure.com/courses/42/assignments/7?module_item_id=12&title=hello%20world#rubric", "canvas-courses://cuhsd.instructure.com/courses/42/assignments/7?module_item_id=12&title=hello%20world#rubric"),
    ("https://cuhsd.instructure.com:443/calendar", "canvas-courses://cuhsd.instructure.com/calendar"),
    ("https://study-1.floot.app/login", nil),
    ("https://example.com/courses/42/assignments/7", nil),
    ("https://cuhsd.instructure.com.example.com/courses/42", nil),
    ("https://name:secret@cuhsd.instructure.com/courses/42", nil),
    ("https://cuhsd.instructure.com:8080/courses/42", nil),
    ("http://cuhsd.instructure.com/courses/42", nil),
    ("mailto:hello@example.com", nil)
]
for (input, expected) in links {
    let actual = CanvasLink.appURL(for: URL(string: input)!)?.absoluteString
    precondition(actual == expected, "Unexpected destination for \(input): \(actual ?? "none")")
}
print("Passed \(links.count) Canvas link routing checks")
