import SwiftUI

@main
struct AfterclassApp: App {
    var body: some Scene {
        WindowGroup {
            TrackerView()
                .preferredColorScheme(.light)
        }
    }
}
