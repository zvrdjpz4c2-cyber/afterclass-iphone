import Foundation

enum CanvasLink {
    static func appURL(for webURL: URL) -> URL? {
        guard var parts = URLComponents(url: webURL, resolvingAgainstBaseURL: false),
              parts.scheme?.lowercased() == "https",
              parts.host?.lowercased() == "cuhsd.instructure.com",
              parts.user == nil, parts.password == nil,
              parts.port == nil || parts.port == 443 else { return nil }

        // Canvas Student registers this scheme and routes the same course paths.
        parts.scheme = "canvas-courses"
        parts.port = nil
        return parts.url
    }
}
